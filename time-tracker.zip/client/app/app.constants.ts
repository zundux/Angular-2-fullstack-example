// import shared from '../../server/config/environment/shared';
// declare let shared: any;
// shared = {
//   env: process.env.NODE_ENV,
//   port: process.env.PORT || 9000,
//   // List of user roles
//   userRoles: ['guest', 'user', 'admin']
// };
//
// export default shared;
export * from '../../server/config/environment/shared.js';
