// 'use strict';
// import angular from 'angular';
// import SettingsController from './settings.controller';
//
// export default angular.module('angularFullstack.settings', [])
//   .controller('SettingsController', SettingsController)
//   .name;
// export * from './settings.module';
