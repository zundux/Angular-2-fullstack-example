import {LoginComponent} from './login.component';

export const STATES = [{
  name: 'login',
  url: '/login',
  component: LoginComponent,
}];

