import {Component} from '@angular/core';

@Component({
  selector: 'footer',
  template: require('./footer.pug'),
  styles: [require('./footer.scss')]
})
export class FooterComponent {
}
